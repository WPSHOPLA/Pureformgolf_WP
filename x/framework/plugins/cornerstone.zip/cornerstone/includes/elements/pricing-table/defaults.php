<?php

/**
 * Element Defaults: Pricing Table
 */

return array(
	'id'         => '',
	'class'      => '',
	'style'      => '',
);